package com.stigma15.pandu.Activity

object helper {
    const val REQUEST_ADD = 100
    const val RESULT_ADD = 101
}